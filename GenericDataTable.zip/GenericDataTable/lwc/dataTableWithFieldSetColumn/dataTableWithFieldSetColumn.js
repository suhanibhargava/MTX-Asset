import { LightningElement, api, track } from "lwc";

export default class DataTableWithFieldSetColumn extends LightningElement {
  @api column;
  @api record;

  get value() {
    console.log(this.column.fieldName);
    console.log(this.record[this.column.fieldName]);

    if (
      this.column &&
      this.record &&
      this.column.fieldName &&
      this.record[this.column.fieldName]
    ) {
      return this.record[this.column.fieldName];
    } else {
      return "";
    }
  }
}
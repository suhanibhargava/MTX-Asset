import { LightningElement, api, track } from "lwc";
import getFieldsAndRecords from "@salesforce/apex/DataTableWithFieldSetController.getFieldsAndRecords";

export default class DataTableWithFieldSet extends LightningElement {
  @api recordId;
  @api label;
  @api sfdcObjectApiName;
  @api fieldSetName;
  @api criteriaFieldAPIName;
  @api firstColumnAsRecordHyperLink;

  @track columns;
  @track tableData;
  @track isNoChildData;

  recordCount;
  lblobjectName;

  connectedCallback() {
    let firstTimeEntry = false;
    let firstFieldAPI;

    //make an implicit call to fetch records from database
    getFieldsAndRecords({
      strObjectApiName: this.sfdcObjectApiName,
      strfieldSetName: this.fieldSetName,
      criteriaField: this.criteriaFieldAPIName,
      criteriaFieldValue: this.recordId
    })
      .then((data) => {
        let objStr = JSON.parse(data);
        let listOfFields = JSON.parse(Object.values(objStr)[1]);
        let listOfRecords = JSON.parse(Object.values(objStr)[0]);

        let items = [];

        listOfFields.map((element) => {
          //it will enter this if-block just once
          if (
            this.firstColumnAsRecordHyperLink != null &&
            this.firstColumnAsRecordHyperLink == "Yes" &&
            firstTimeEntry == false
          ) {
            firstFieldAPI = element.fieldPath;
            //perpare first column as hyperlink
            items = [
              ...items,
              {
                label: element.label,
                fieldName: "URLField",
                fixedWidth: 150,
                type: "url",
                typeAttributes: {
                  label: {
                    fieldName: element.fieldPath
                  },
                  target: "_blank"
                },
                sortable: true
              }
            ];
            firstTimeEntry = true;
          } else {
            items = [
              ...items,
              { label: element.label, fieldName: element.fieldPath }
            ];
          }
        });

        this.columns = items;
        this.tableData = listOfRecords;

        if (listOfRecords && listOfRecords.length > 0) {
          this.isNoChildData = false;
        } else {
          this.isNoChildData = true;
        }

        if (
          this.firstColumnAsRecordHyperLink != null &&
          this.firstColumnAsRecordHyperLink == "Yes"
        ) {
          let URLField;
          //retrieve Id, create URL with Id and push it into the array
          this.tableData = listOfRecords.map((item) => {
            URLField =
              "/lightning/r/" +
              this.sfdcObjectApiName +
              "/" +
              item.Id +
              "/view";
            return { ...item, URLField };
          });

          this.tableData = this.tableData.filter(
            (item) => item.fieldPath != firstFieldAPI
          );
        }

        this.lblobjectName = this.sfdcObjectApiName;
        this.recordCount = this.tableData.length;
        this.error = undefined;
      })
      .catch((error) => {
        this.error = error;
        console.log("error", error);
        this.tableData = undefined;
        this.lblobjectName = this.sfdcObjectApiName;
      });
  }
}